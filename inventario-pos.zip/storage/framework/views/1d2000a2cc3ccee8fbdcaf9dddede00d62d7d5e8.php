<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Company Information</h6>
        </div>
        <div class="card-body">

            <form method="POST" action="<?php echo e(route('companies.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row mt-3">

                    <div class="col">
                        <label for="exampleFormControlTextarea1">Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($company ? $company->name : ''); ?>" required>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlInput1">RUC</label>
                        <input type="text" class="form-control" id="ruc" name="ruc" value="<?php echo e($company ? $company->ruc : ''); ?>" required>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col">
                        <label for="exampleFormControlTextarea1">Address</label>
                        <input type="text" class="form-control" id="address" name="address" value="<?php echo e($company ? $company->address : ''); ?>" required>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col">
                        <label for="exampleFormControlTextarea1">Phone</label>
                        <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($company ? $company->phone : ''); ?>" required>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlInput1">Cellphone</label>
                        <input type="number" class="form-control" id="cellphone" name="cellphone" value="<?php echo e($company ? $company->cellphone : ''); ?>" required>
                        <input type="hidden" class="form-control" id="user_id" name="user_id" value="<?php echo e(Auth::user()->id); ?>" required>

                    </div>
                </div>
                <br>

                <button type="submit" class="btn btn-primary btn-lg btn-block">Save</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventario-pos\resources\views/companies/create.blade.php ENDPATH**/ ?>