<table id="product-table" class="table" style="width:100%">
    <thead>
        <tr>
            <th>Id</th>
            <th>Sku</th>
            <th>Name</th>
            <th>Description</th>
            <th>Categories</th>
            <th>Purchase Price per Uni</th>
            <th>Selling Price per Unit</th>
            <th>Utility</th>
            <th>Stock</th>
            <th>Created At</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->id); ?></td>
                <td><?php echo e($product->sku); ?></td>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->description); ?></td>

                <td>
                    <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge badge-primary"><?php echo e($item->name); ?>  , </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td><?php echo e($product->purchase_price); ?></td>
                <td><?php echo e($product->selling_price); ?></td>
                <td><?php echo e($product->utility); ?></td>
                <td><?php echo e($product->stock); ?></td>
                <td><?php echo e($product->created_at); ?></td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>
<?php /**PATH C:\laragon\www\inventario-pos\resources\views/exports/products.blade.php ENDPATH**/ ?>