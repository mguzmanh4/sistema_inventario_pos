<?php $__env->startSection('styles'); ?>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.13.5/css/selectize.bootstrap4.min.css" integrity="sha512-VL5zQAJyFw5RL9wN3a5nF508dBqgOAYOZeww5RuEq8A8JQLiWy20iG2lLyiTuF6bv7gz48UGMcxuMlUycoHfJw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Create User</h6>
        </div>
        <div class="card-body">

            <form method="POST" action="<?php echo e(route('users.update',[$user->id])); ?>">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col">
                        <label for="exampleFormControlTextarea1">Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>" required>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlInput1">First Name</label>
                        <input type="text" class="form-control" id="first_name" name="first_name"value="<?php echo e($user->first_name); ?>" required>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlInput1">Last Name</label>
                        <input type="text" class="form-control" id="last_name" name="last_name"value="<?php echo e($user->last_name); ?>" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col">
                        <label for="exampleFormControlTextarea1">User Name</label>
                        <input type="text" class="form-control" id="username" name="username" value="<?php echo e($user->username); ?>" required>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlInput1">Dni</label>
                        <input type="number" class="form-control" id="dni" name="dni" value="<?php echo e($user->dni); ?>" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col">
                        <label for="exampleFormControlTextarea1">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Role</label>
                    <select class="form-control" name="roles[]" id="roles">
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('roles', [])) || $user->roles->contains($id)) ? 'selected' : ''); ?>><?php echo e($role); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary btn-lg btn-block">Save</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.13.5/js/standalone/selectize.min.js" integrity="sha512-JFjt3Gb92wFay5Pu6b0UCH9JIOkOGEfjIi7yykNWUwj55DBBp79VIJ9EPUzNimZ6FvX41jlTHpWFUQjog8P/sw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        $("#roles").selectize({
            hideSelected: true,

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventario-pos\resources\views\companies\edit.blade.php ENDPATH**/ ?>