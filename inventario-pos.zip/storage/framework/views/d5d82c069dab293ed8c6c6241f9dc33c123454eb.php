<table id="order-table" class="table" style="width:100%">
    <thead>
        <tr>
            <th>Id</th>
            <th>User</th>
            <th>Client Name</th>
            <th>Products</th>
            <th>Total</th>
            <th>Created At</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($order->id); ?></td>
                <td><?php echo e($order->user->name); ?></td>
                <td><?php echo e($order->client_name); ?></td>
                <td>
                    <?php
                        $suma = 0 ;
                    ?>
                    <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge badge-primary"><?php echo e($item->name); ?>  , </span>
                        <?php
                            $suma += $item->purchase_price;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>S/ <?php echo e($suma); ?></td>
                <td>S/ <?php echo e($order->created_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>
<?php /**PATH C:\laragon\www\inventario-pos\resources\views/exports/orders.blade.php ENDPATH**/ ?>