<table id="product-table" class="table" style="width:100%">
    <thead>
        <tr>
            <th>Id</th>
            <th>Product</th>
            <th>Sku</th>
            <th>Stock</th>
            <th>Purchased Amount</th>
            <th>Vendor</th>
            <th>Cost</th>
            <th>Created At</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $shoppings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shopping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($shopping->id); ?></td>
                <td><?php echo e($shopping->product->name); ?></td>
                <td><?php echo e($shopping->product->sku); ?></td>
                <td><?php echo e($shopping->product->stock); ?></td>
                <td><?php echo e($shopping->purchased_amount); ?></td>
                <td><?php echo e($shopping->vendor); ?></td>
                <td><?php echo e($shopping->cost); ?></td>
                <td><?php echo e($shopping->created_at); ?></td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>
<?php /**PATH C:\laragon\www\inventario-pos\resources\views/exports/shoppings.blade.php ENDPATH**/ ?>